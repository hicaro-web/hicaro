/* =========================================================
   بيانات الموقع — عدّل من هنا بسهولة
   ========================================================= */

const SITE_DATA = {
  skills: [
    "تطوير البوتات",
    "JavaScript",
    "Node.js",
    "تطوير البرمجيات",
    "Git / GitHub",
    "إدارة وتنظيم المجتمعات"
  ],

  // أضف المشاريع الحقيقية هنا مستقبلًا:
  // {
  //   name: "اسم المشروع",
  //   description: "وصف مختصر",
  //   tech: ["JavaScript", "Node.js"],
  //   url: "https://example.com",
  //   github: "https://github.com/..."
  // }
  projects: []
};

const skillsGrid = document.querySelector("#skills-grid");
const projectsGrid = document.querySelector("#projects-grid");

SITE_DATA.skills.forEach((skill, index) => {
  const card = document.createElement("article");
  card.className = "skill-card reveal";
  card.innerHTML = `
    <span class="skill-index">${String(index + 1).padStart(2, "0")}</span>
    <h3>${escapeHTML(skill)}</h3>
  `;
  skillsGrid.appendChild(card);
});

if (SITE_DATA.projects.length === 0) {
  projectsGrid.innerHTML = `
    <article class="project-card reveal">
      <div>
        <span class="eyebrow">جاهز للإضافة</span>
        <h3>لا توجد مشاريع منشورة حاليًا</h3>
        <p>أضف مشاريعك الحقيقية داخل مصفوفة <strong>SITE_DATA.projects</strong> في ملف JavaScript.</p>
      </div>
    </article>
  `;
} else {
  SITE_DATA.projects.forEach((project) => {
    const card = document.createElement("article");
    card.className = "project-card reveal";
    card.style.display = "block";
    card.style.textAlign = "right";
    card.innerHTML = `
      <span class="eyebrow">${escapeHTML((project.tech || []).join(" · "))}</span>
      <h3>${escapeHTML(project.name)}</h3>
      <p>${escapeHTML(project.description)}</p>
      <div class="hero-actions" style="justify-content:flex-start">
        ${project.url ? `<a class="btn btn-primary" href="${safeURL(project.url)}" target="_blank" rel="noopener noreferrer">عرض المشروع</a>` : ""}
        ${project.github ? `<a class="btn btn-secondary" href="${safeURL(project.github)}" target="_blank" rel="noopener noreferrer">GitHub</a>` : ""}
      </div>
    `;
    projectsGrid.appendChild(card);
  });
}

function escapeHTML(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function safeURL(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) ? url.href : "#";
  } catch {
    return "#";
  }
}

/* Navbar */
const header = document.querySelector("#site-header");
const menuToggle = document.querySelector("#menu-toggle");
const navLinks = document.querySelector("#nav-links");

window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 20);
}, { passive: true });

menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "إغلاق القائمة" : "فتح القائمة");
});

navLinks.addEventListener("click", (event) => {
  if (event.target.matches("a")) {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "فتح القائمة");
  }
});

/* Active navigation */
const sections = [...document.querySelectorAll("main section[id]")];
const navAnchors = [...document.querySelectorAll(".nav-links a")];

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    navAnchors.forEach((anchor) => {
      anchor.classList.toggle(
        "active",
        anchor.getAttribute("href") === `#${entry.target.id}`
      );
    });
  });
}, { rootMargin: "-35% 0px -55% 0px" });

sections.forEach((section) => sectionObserver.observe(section));

/* Reveal on scroll */
const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add("visible");
    observer.unobserve(entry.target);
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach((element) => {
  revealObserver.observe(element);
});

/* Visitor number — fixed demo value, not real tracking */
const visitorNumber = document.querySelector(".visitor-number");
const target = Number(visitorNumber.dataset.target);
let visitorAnimated = false;

const visitorObserver = new IntersectionObserver((entries, observer) => {
  if (!entries[0].isIntersecting || visitorAnimated) return;
  visitorAnimated = true;

  const duration = 900;
  const start = performance.now();

  const tick = (now) => {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    visitorNumber.textContent = Math.round(target * eased).toLocaleString("en-US");
    if (progress < 1) requestAnimationFrame(tick);
  };

  requestAnimationFrame(tick);
  observer.disconnect();
}, { threshold: 0.5 });

visitorObserver.observe(visitorNumber);
