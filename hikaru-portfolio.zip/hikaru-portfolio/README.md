# هيكارو — Personal Portfolio

موقع شخصي عربي RTL بنمط Dark Mode، مبني بـ HTML + CSS + JavaScript بدون Framework أو Backend.

## التشغيل

لا يحتاج إلى build أو npm.

افتح `index.html` مباشرة، أو ارفعه إلى أي استضافة Static.

## الصورة الرئيسية

ضع صورة هيكارو هنا:

`public/images/hikaru.png`

لا يوجد اعتماد على صورة خارجية.

## تعديل البيانات

افتح:

`script.js`

وعدّل `SITE_DATA` لإضافة أو تعديل المهارات والمشاريع.

### مثال مشروع

```js
{
  name: "اسم المشروع",
  description: "وصف مختصر للمشروع.",
  tech: ["JavaScript", "Node.js"],
  url: "https://example.com",
  github: "https://github.com/..."
}
```

## واتساب

الرابط الحالي مضبوط على:

`https://wa.me/201070185184`

## عداد الزوار

`11,856` رقم ثابت وتجريبي فقط. لا توجد قاعدة بيانات أو Analytics أو Visitor Tracking.

## الهيكل

- `index.html`
- `styles.css`
- `script.js`
- `public/images/hikaru.png` ← ضع الصورة هنا
